#ifndef CHRONO_H
#define CHRONO_H


class chrono
{
    public:
        chrono();
        virtual ~chrono();
        //void start();

    protected:

    private:
};

#endif // CHRONO_H
