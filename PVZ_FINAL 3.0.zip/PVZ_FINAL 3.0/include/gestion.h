#ifndef GESTION_H
#define GESTION_H


class gestion
{
    public:
        gestion();
        virtual ~gestion();
        int vie;
        void life();
        void gameOver();

    protected:

    private:
};

#endif // GESTION_H
