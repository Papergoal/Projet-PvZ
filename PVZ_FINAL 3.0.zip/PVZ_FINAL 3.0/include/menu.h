#ifndef MENU_H
#define MENU_H


class menu
{
    public:
        menu();
        virtual ~menu();
        void mennu();
        int men;
        void menuTourel();
        int a;
        int b;
        int tour;
        void piece();


    protected:

    private:
};

#endif // MENU_H
