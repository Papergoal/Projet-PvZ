#include "Ennemies.h"
#include <maps.h>

Ennemies::Ennemies()
{
    //ctor
}

Ennemies::~Ennemies()
{
    //dtor
}


void Ennemies::DeplacementEnemi(){
    maps* mp= new maps();


        for (int i=0; i<10; i++){
            for(int j=0; j<20; j++){
                   if (mp->mapss[i][j]==5){
                      x =i;
                      y=j;
                   }
            }
        }
        mp->mapss[x][y-1]= mp->mapss[x][y];
        mp->mapss[x][y]= 0;

}

void Ennemies::gameOver(){

}

/*void Ennemies::spawn(){

if (vague==1){
     if (difftime(arrivee,depart)==15){

                mapss[random][18]=5;

            }

                if (difftime(arrivee,depart)==random1){

                mapss[a][18]=5;
            }
}

if (vague==2){


    }
}*/
