#include "maps.h"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <iostream>
#include <menu.h>
#include <windows.h>
#include "gestion.h"


using namespace std;

maps::maps()
{
    srand(time(NULL));
    random=   (rand() % (8 - 1 + 1)) + 1;

    for(int i=0;i<10;i++){
        for(int j=1;j<19;j++){
            mapss[0][j]=1;
            mapss[1][j]=0;
            mapss[2][j]=0;
            mapss[3][j]=0;
            mapss[4][j]=0;
            mapss[5][j]=0;
            mapss[6][j]=0;
            mapss[7][j]=0;
            mapss[8][j]=0;
            mapss[9][j]=1;
            mapss[i][0]=1;
            mapss[i][19]=1;
        }
    }
}

maps::~maps()
{
    //dtor
}

void calcTime(){

}

void maps::mapi(){
    srand(time(NULL));
    menu* mn = new menu();
    gestion* gest = new gestion();

    random=   (rand() % (8 - 1 + 1)) + 1;
    int a = (rand()%(8-1+1))+1;
    random1= rand()%10 + 20;
    random2= rand()%10 + 30;
    vague=1;
    time_t depart, arrivee;
    time(&depart);


    while(true){

        while(start!=('p')){
            cout<<""<<endl;
            cout<<"vous avez: "<<argents<< "pieces"<<endl;
            cout<<""<<endl;
            cout<<""<<endl;
            cout<<"1: Tour ->prix 100; 10 degats ;  50 vie ; 0,8 vitesse"<<endl;
            cout<<"2: Tour ->prix 100; 10 degats ;  50 vie ; 0,8 vitesse"<<endl;
            cout<<"3: Tour -> 10 degats   50 vie  0,8 vitesse"<<endl;
            cout<<"4: Tour -> 10 degats   50 vie  0,8 vitesse"<<endl;
            cout<<"5: Tour -> 10 degats   50 vie  0,8 vitesse"<<endl;
            cout<<"Choisir votre defense:  "<<endl;
            cin>>tour;
            cout<<"Choisissez la hauteur"<< endl;
            cin>>a;
            cout<<"Choisissez la largeur"<<endl;
            cin>>b;
             cout<<"Appuyez sur la touche p pour lancer la partie ou une autre touche du clavier pour choisir sa defense"<<endl;
            cin>>start;
            Sleep(1000);
            if (tour ==1 && argents>=100){
                argents -= 100;
                mapss[a][b]=2;
            }

    }


     for (int i=0; i<10; i++){
        for(int j=0; j<20; j++){

        gest->life();
        gest->gameOver();
        if(vague==1){
               if (difftime(arrivee,depart)==15){

                mapss[random][18]=5;

            }

                if (difftime(arrivee,depart)==random1){

                mapss[a][18]=5;
            }

            if (difftime(arrivee,depart)==random2){

                mapss[a][18]=5;
            }
        }


            if (mapCounter==20){
                std::cout<<""<<std::endl;
                mapCounter=0;
            }
            if(mapss[i][j]==1){
                std::cout<<"1";
            }else if (mapss[i][j]==0){
                std::cout<<" ";
            }else if (mapss[i][j]==5){
                std::cout<<"M";
                x=i;
                y=j;
            }else if (mapss[i][j]==2){
                std::cout<<"T";
            }
            mapCounter++;
            }
            if(mapss[x][y]==5)
            {
                mapss[x][y]= 0;
                mapss[x][y-1]= 5;

                if(mapss[x][0]==5){
                    mapss[x][0]=1;
                }
            }
        }

    time(&arrivee);

    cout<<""<<endl;
    cout<<"******************************"<<endl;
    cout<<"*     Temps: "<< difftime(arrivee, depart) <<"   secondes   *"<<endl;
    cout<<"******************************"<<endl;
    cout<<""<<endl;
    cout<<"Vous avez: "<<argents<<"     piece"<<endl;
    cout<<"Vous avez: "<<gest->vie<<" vie"<<endl;

    argents+=2;
        Sleep(500);
        system("cls");
        }
    }







