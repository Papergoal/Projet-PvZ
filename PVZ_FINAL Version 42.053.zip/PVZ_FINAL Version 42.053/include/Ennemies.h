#ifndef ENNEMIES_H
#define ENNEMIES_H


class Ennemies
{
    public:
        Ennemies();
        virtual ~Ennemies();
        void DeplacementEnemi();
        int x;
        int y;
        void spawn();
        int vague;
        void gameOver();

    protected:

    private:
};

#endif // ENNEMIES_H
