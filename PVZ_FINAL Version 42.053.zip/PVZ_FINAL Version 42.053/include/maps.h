#ifndef MAPS_H
#define MAPS_H


class maps
{
    public:
        maps();
        virtual ~maps();
        virtual void mapi();
        int mapCounter=0;
        void DeplacementEnemi();
        int mapss [10][20];
        int x;
        int y;
        int random;
        int a;
        int b;
        char start;
        int argents=200 ;
        int random1;
        int random2;
        int vague;
        int tour;
        bool feuGerer;
        int c;
        int d;
        int vie;



    protected:


    private:
};

#endif // MAPS_H

