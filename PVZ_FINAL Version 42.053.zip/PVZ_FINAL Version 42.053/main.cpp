#include <iostream>
#include <maps.h>
#include <Ennemies.h>
#include <menu.h>
#include <gestion.h>
using namespace std;

int main()
{
    menu* mn = new menu();
    gestion* gest = new gestion();
    mn->mennu();

}
