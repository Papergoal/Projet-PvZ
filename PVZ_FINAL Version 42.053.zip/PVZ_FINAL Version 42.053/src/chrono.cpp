#include "chrono.h"

chrono::chrono()
{
    //ctor
}

chrono::~chrono()
{
    //dtor
}

