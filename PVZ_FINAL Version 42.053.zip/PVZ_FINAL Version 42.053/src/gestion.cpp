#include "gestion.h"
#include "maps.h"
#include "windows.h"
#include "iostream"

using namespace std;

gestion::gestion()
{
    vie=3;
    //ctor
}

gestion::~gestion()
{
    //dtor
}

void gestion::life(){


/*        if (mp->mapss[0][1]==5){
            vie=vie-1;
        }
        if (mp->mapss[1][1]==5){
            vie=vie-1;
        }
        if (mp->mapss[2][1]==5){
            vie=vie-1;
        }
        if (mp->mapss[3][1]==5){
            vie=vie-1;
        }
        if (mp->mapss[4][1]==5){
            vie=vie-1;
        }
        if (mp->mapss[5][1]==5){
            vie=vie-1;
        }
        if (mp->mapss[6][1]==5){
            vie=vie-1;
        }
        if (mp->mapss[7][1]==5){
            vie=vie-1;
        }
        if (mp->mapss[8][1]==5){
            vie=vie-1;
        }
        if (mp->mapss[9][1]==5){
            vie=vie-1;
        }

*/
}

void gestion::gameOver(){

        if (vie<=0){
            system("cls");
            std::cout<<"GAME OVER";
        }


}
